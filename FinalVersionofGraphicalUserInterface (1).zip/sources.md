## Sources
To clear buttons / labels:
https://stackoverflow.com/questions/9827517/delete-a-specific-button#:~:text=Comments,-Add%20a%20comment&text=The%20easiest%20method:,is%20the%20button%20to%20remove.

For drop down menus - combo box
https://docs.oracle.com/javase/tutorial/uiswing/components/combobox.html

Using an image for a button: 
https://stackoverflow.com/questions/28732022/how-to-create-a-jbutton-with-only-an-image

Image resizing:
https://stackoverflow.com/questions/5895829/resizing-image-in-java

Removing Action Listeners:
https://docs.oracle.com/javase/8/docs/api/javax/swing/AbstractButton.html
https://docs.oracle.com/javase/tutorial/uiswing/events/actionlistener.html
https://stackoverflow.com/questions/17604850/action-listener-is-not-working-on-certain-buttons#:~:text=It%20is%20resource%20inefficient%20and,when%20you%20draw%20that%20map.

Try Catch:
https://rollbar.com/blog/java-numberformatexception/#:~:text=this%20exception%20effectively:-,1.,);%20%7D%20%7D

JTable:
https://www.geeksforgeeks.org/java/java-swing-jtable/
https://docs.oracle.com/javase/tutorial/uiswing/components/table.html#:~:text=by%20data%20type.-,Using%20Custom%20Renderers,by%20creating%20a%20JTable%20subclass.&text=If%20extending%20DefaultTableCellRenderer%20is%20insufficient,show%20how%20it%20is%20implemented.
https://forums.oracle.com/ords/apexds/post/multi-line-cells-in-a-jtable-8839

OOP:
https://www.geeksforgeeks.org/java/different-ways-create-objects-java/

Making JTables Ineditable:
https://www.daniweb.com/programming/software-development/threads/279060/how-do-you-prevent-editing-of-jtable-cells#:~:text=Selection%20flags%20(row/column/,grayed%20out%20and%20non%2Dinteractive.

Wrap text based on words:
https://stackoverflow.com/questions/26420428/how-to-word-wrap-text-in-jlabel

Colors of specifc cells:
https://stackoverflow.com/questions/5673430/java-jtable-change-cell-color#comment6476177_5673606
https://docs.oracle.com/javase/8/docs/api/javax/swing/table/DefaultTableCellRenderer.html

Set Background for tables
https://forums.codeguru.com/showthread.php?32386-JTable-background-color&p=89031

Animal Crossing:
https://interfaceingame.com/screenshots/animal-crossing-new-horizons-achievements/
https://nookipedia.com/wiki/Category:New_Horizons_house_shape_icon#/media/File:Player_House_(Fantasy)_NH_Icon_cropped.png

Colors:
https://docs.oracle.com/javase/8/docs/api/java/awt/Color.html

Buttons/images with no background:
https://forums.oracle.com/ords/apexds/post/transparent-jbutton-8202

For stock information:
https://www.howthemarketworks.com/

### Answer the questions below before submitting this task.

1. Did you use any generative AI tool for this project? (Yes/No)

→ No

2. Did you use any documentation or tutorials? (Yes/No)

→ Yes

3. Did you use any code or information from external online sources? (Yes/No)

→ Yes

4. Did you have any help from anyone aside from the teacher? (Yes/No)

→ No


**If you answered 'Yes' to any of the above questions, continue below.**

1a. If you answered 'Yes' to Question 1, provide the share link to the AI chat history. 

→

1b. If you answered 'Yes' to Question 1, describe how your use of AI is appropriate according to the Course Outline.

→

2a. If you answered 'Yes' to Question 2, provide the link to the documentation or tutorial.

→ Links:
To clear buttons / labels:
https://stackoverflow.com/questions/9827517/delete-a-specific-button#:~:text=Comments,-Add%20a%20comment&text=The%20easiest%20method:,is%20the%20button%20to%20remove.

For drop down menus - combo box
https://docs.oracle.com/javase/tutorial/uiswing/components/combobox.html

Using an image for a button: 
https://stackoverflow.com/questions/28732022/how-to-create-a-jbutton-with-only-an-image

Image resizing:
https://stackoverflow.com/questions/5895829/resizing-image-in-java

Removing Action Listeners:
https://docs.oracle.com/javase/8/docs/api/javax/swing/AbstractButton.html
https://docs.oracle.com/javase/tutorial/uiswing/events/actionlistener.html
https://stackoverflow.com/questions/17604850/action-listener-is-not-working-on-certain-buttons#:~:text=It%20is%20resource%20inefficient%20and,when%20you%20draw%20that%20map.

Try Catch:
https://rollbar.com/blog/java-numberformatexception/#:~:text=this%20exception%20effectively:-,1.,);%20%7D%20%7D

JTable:
https://www.geeksforgeeks.org/java/java-swing-jtable/
https://docs.oracle.com/javase/tutorial/uiswing/components/table.html#:~:text=by%20data%20type.-,Using%20Custom%20Renderers,by%20creating%20a%20JTable%20subclass.&text=If%20extending%20DefaultTableCellRenderer%20is%20insufficient,show%20how%20it%20is%20implemented.
https://forums.oracle.com/ords/apexds/post/multi-line-cells-in-a-jtable-8839

OOP:
https://www.geeksforgeeks.org/java/different-ways-create-objects-java/

Making JTables Ineditable:
https://www.daniweb.com/programming/software-development/threads/279060/how-do-you-prevent-editing-of-jtable-cells#:~:text=Selection%20flags%20(row/column/,grayed%20out%20and%20non%2Dinteractive.

Wrap text based on words:
https://stackoverflow.com/questions/26420428/how-to-word-wrap-text-in-jlabel

Set Background for tables
https://forums.codeguru.com/showthread.php?32386-JTable-background-color&p=89031

Animal Crossing:
https://interfaceingame.com/screenshots/animal-crossing-new-horizons-achievements/
https://nookipedia.com/wiki/Category:New_Horizons_house_shape_icon#/media/File:Player_House_(Fantasy)_NH_Icon_cropped.png

Colors:
https://docs.oracle.com/javase/8/docs/api/java/awt/Color.html

Buttons/images with no background:
https://forums.oracle.com/ords/apexds/post/transparent-jbutton-8202

For stock information:
https://www.howthemarketworks.com/

2b. If you answered 'Yes' to Question 2, describe the information you used and indicate any code you used from the source.

→ Here:

To clear buttons / labels:
.removeAll()

For drop down menus - combo box
JComboBox

Using an image for a button - setting it to a button

Image resizing:
getScaledInstance of an image

Removing Action Listeners:
I used this to make the forloop that removes all the action listeners for the buttons:
for (JButton button : allButtons){
    for (ActionListener al : button.getActionListeners()){
        button.removeActionListener(al);
    }
}

Try Catch:
NumberFormatException for qqNum

JTable:
How to make a JTable

OOP:
I used for OOP

Making JTables ineditable:
table = new JTable(row, column){
   public boolean isCellEditable(int row, int column){
        return false;
   }
};

Wrap text based on words:
used to wrap text, these methods:
tutorialArea.setLineWrap(true);
tutorialArea.setWrapStyleWord(true);

Set Background for tables
to learn these methods
allStocksTable.setBackground(niceGreenColor);
sp.getViewport().setBackground(niceGreenColor);

Colors:
Color colorEx = new Color(int r, int g, int b);

Buttons/images with no background:
used in this portion:
add5Button.setBackground(Color.WHITE);
add5Button.setContentAreaFilled(false);
add5Button.setBorderPainted(false);
add5Button.setOpaque(false);


3a. If you answered 'Yes' to Question 3, provide the link to the online source.

→ Colors of specifc cells:
https://stackoverflow.com/questions/5673430/java-jtable-change-cell-color#comment6476177_5673606
https://docs.oracle.com/javase/8/docs/api/javax/swing/table/DefaultTableCellRenderer.html

3b. If you answered 'Yes' to Question 3, describe the information you used and indicate any code you used from the source.

→ Colors of specifc cells:
this is what I used to make colorRenderer(), it sources the 
code from stack overflow with changes
code from stack overflow:
public class StatusColumnCellRenderer extends DefaultTableCellRenderer {
  @Override
  public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col) {

    //Cells are by default rendered as a JLabel.
    JLabel l = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);

    //Get the status for the current row.
    CustomTableModel tableModel = (CustomTableModel) table.getModel();
    if (tableModel.getStatus(row) == CustomTableModel.APPROVED) {
      l.setBackground(Color.GREEN);
    } else {
      l.setBackground(Color.RED);
    }

  //Return the JLabel which renders the cell.
  return l;

}
Additonally I used the documentation to understand how it works
and the different components to override the regular cell renderer


4a. If you answered 'Yes' to Question 4, indicate who helped you (e.g. a classmate, a relative, a tutor, etc.). If it is someone your teacher knows, provide their name.

→

4b. If you answered 'Yes' to Question 4, indicate how the person helped you. Specify all parts of your code they helped you with.

→


### Generative AI Use 

**In this assignment, you may use generative AI if:**

* The only code you paste into the AI tool is the code you wrote (not the assignment instructions, the starter code, or the docstring).
* You include something to the effect of "give me a hint, don't tell me the answer" in your prompts to ensure AI does not give you the full answer.
* You only use AI for debugging purposes once you have written most of the solution.
* You include your full AI chat history above.


### Reminders

* It is considered cheating if you paste all or most of the assignment instructions or starter code into a generative AI tool.
* It is considered cheating if you send someone your entire program or let them take a picture of your program.
* It is considered cheating if you copy large amounts of code from your peers or get someone to do all or most of the work for you.
* Each assignment has a file history that indicates when code is pasted in.
* Cheating or lying about your sources (e.g. saying you didn't get help when you actually did) can lead to disciplinary actions.